export const content = {
  movies: [
    {
      id: 1,
      title: 'Inception',
      image: 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&w=600&q=80',
      rating: '8.8',
      year: '2010',
      duration: '2h 28min'
    },
    {
      id: 2,
      title: 'The Dark Knight',
      image: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&w=600&q=80',
      rating: '9.0',
      year: '2008',
      duration: '2h 32min'
    },
    {
      id: 3,
      title: 'Interstellar',
      image: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?auto=format&fit=crop&w=600&q=80',
      rating: '8.6',
      year: '2014',
      duration: '2h 49min'
    },
    {
      id: 4,
      title: 'The Matrix',
      image: 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=600&q=80',
      rating: '8.7',
      year: '1999',
      duration: '2h 16min'
    }
  ],
  series: [
    {
      id: 5,
      title: 'Breaking Bad',
      image: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=600&q=80',
      rating: '9.5',
      year: '2008-2013',
      seasons: '5 Seasons'
    },
    {
      id: 6,
      title: 'Stranger Things',
      image: 'https://images.unsplash.com/photo-1534809027769-b00d750a6bac?auto=format&fit=crop&w=600&q=80',
      rating: '8.7',
      year: '2016-Present',
      seasons: '4 Seasons'
    }
  ],
  anime: [
    {
      id: 7,
      title: 'Attack on Titan',
      image: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=600&q=80',
      rating: '9.0',
      year: '2013-2023',
      seasons: '4 Seasons'
    },
    {
      id: 8,
      title: 'Death Note',
      image: 'https://images.unsplash.com/photo-1541562232579-512a21360020?auto=format&fit=crop&w=600&q=80',
      rating: '9.0',
      year: '2006-2007',
      seasons: '1 Season'
    }
  ]
};