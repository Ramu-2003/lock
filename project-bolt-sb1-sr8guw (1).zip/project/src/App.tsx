import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { TabSelector } from './components/TabSelector';
import { ContentCard } from './components/ContentCard';
import { VideoPlayer } from './components/VideoPlayer';
import { content } from './data/content';

const tabs = [
  { id: 'movies', label: 'Movies' },
  { id: 'series', label: 'Web Series' },
  { id: 'anime', label: 'Anime' }
];

function App() {
  const [activeTab, setActiveTab] = useState('movies');
  const [searchQuery, setSearchQuery] = useState('');
  const [playingVideoId, setPlayingVideoId] = useState<number | null>(null);

  const handleWatch = (id: number) => {
    setPlayingVideoId(id);
  };

  const handleDownload = (id: number) => {
    // Implement download functionality
    console.log('Downloading content with ID:', id);
  };

  const filteredContent = content[activeTab as keyof typeof content].filter(
    (item) => item.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Navbar searchQuery={searchQuery} onSearchChange={setSearchQuery} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
        <TabSelector
          tabs={tabs}
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredContent.map((item) => (
            <ContentCard
              key={item.id}
              item={item}
              onWatch={handleWatch}
              onDownload={handleDownload}
            />
          ))}
        </div>

        {filteredContent.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400">No content found matching your search.</p>
          </div>
        )}
      </main>

      {playingVideoId && (
        <VideoPlayer
          videoId={playingVideoId}
          onClose={() => setPlayingVideoId(null)}
        />
      )}
    </div>
  );
}

export default App;