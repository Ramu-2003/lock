import React, { useState } from 'react';
import { Heart, Play, Download } from 'lucide-react';

interface ContentItem {
  id: number;
  title: string;
  image: string;
  rating: string;
  year: string;
  duration?: string;
  seasons?: string;
}

interface ContentCardProps {
  item: ContentItem;
  onWatch: (id: number) => void;
  onDownload: (id: number) => void;
}

export function ContentCard({ item, onWatch, onDownload }: ContentCardProps) {
  const [isLiked, setIsLiked] = useState(false);

  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden group hover-scale">
      <div className="relative">
        <img
          src={item.image}
          alt={item.title}
          className="w-full h-64 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <button
          onClick={() => onWatch(item.id)}
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-blue-500 rounded-full p-4 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-blue-600"
        >
          <Play className="h-6 w-6" />
        </button>
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold line-clamp-1">{item.title}</h3>
          <button
            onClick={() => setIsLiked(!isLiked)}
            className="focus:outline-none"
          >
            <Heart
              className={`h-5 w-5 cursor-pointer transition-colors ${
                isLiked ? 'text-red-500 fill-current' : 'text-gray-400'
              }`}
            />
          </button>
        </div>
        <div className="flex items-center text-sm text-gray-400 mb-4">
          <span>{item.rating}</span>
          <span className="mx-2">•</span>
          <span>{item.year}</span>
          <span className="mx-2">•</span>
          <span>{'duration' in item ? item.duration : item.seasons}</span>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => onWatch(item.id)}
            className="flex-1 bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 transition-colors flex items-center justify-center space-x-2"
          >
            <Play className="h-4 w-4" />
            <span>Watch Now</span>
          </button>
          <button
            onClick={() => onDownload(item.id)}
            className="px-4 bg-gray-700 text-white py-2 rounded-md hover:bg-gray-600 transition-colors"
            title="Download"
          >
            <Download className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
}