import React from 'react';
import { Menu, Search, Bell, User } from 'lucide-react';

interface NavbarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export function Navbar({ searchQuery, onSearchChange }: NavbarProps) {
  return (
    <nav className="bg-gray-800 fixed w-full z-50 top-0">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Menu className="h-6 w-6 text-gray-400" />
            <span className="ml-4 text-xl font-bold">StreamFlix</span>
          </div>
          <div className="flex-1 max-w-xl px-8">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search movies, series, anime..."
                className="w-full bg-gray-700 rounded-full pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
              />
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Bell className="h-6 w-6 text-gray-400 cursor-pointer hover:text-white transition-colors" />
            <User className="h-6 w-6 text-gray-400 cursor-pointer hover:text-white transition-colors" />
          </div>
        </div>
      </div>
    </nav>
  );
}